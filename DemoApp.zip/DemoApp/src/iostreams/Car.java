package iostreams;

import java.io.Serializable;

public class Car implements Serializable {
		private String model;
		private String company;
		private double price;
		transient private String chassieNo;
		public Car(String model, String company, double price, String chassieNo) {
			this.model = model;
			this.company = company;
			this.price = price;
			this.chassieNo = chassieNo;
		}
		@Override
		public String toString() {
			return "Car [model=" + model + ", company=" + company + ", price=" + price + ", chassieNo=" + chassieNo
					+ "]";
		}
		
		
}
