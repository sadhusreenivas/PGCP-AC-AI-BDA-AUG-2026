package iostreams;
import java.io.*;
public class SerializeEx {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Car car = new Car("TATA SUV","TATA",4500000,"tata@123");
		System.out.println(car);
		
		BufferedOutputStream br = new BufferedOutputStream(new FileOutputStream("C:/Users/cdac/Desktop/files/car.cdac") );
		ObjectOutputStream Oos = new ObjectOutputStream(br);
		Oos.writeObject(car);
		System.out.println("serialization completed");
		Oos.close();
		
		
		BufferedInputStream bi = new BufferedInputStream(new FileInputStream("C:/Users/cdac/Desktop/files/car.cdac"));
		ObjectInputStream ois = new ObjectInputStream(bi);
		Car car2 = (Car)ois.readObject();
	    System.out.println(car2);
		
		
		
		
		ois.close();
		
		
		

	}

}
