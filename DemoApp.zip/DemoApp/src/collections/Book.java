package collections;

import java.util.*;

public class Book {
	int bookId;
	String title;
	String author;
	GENRE genre;
	
	enum GENRE {
		FICTION,
		COMIC,
		PHILOSOPHY,
		HORROR,
		MYSTERY,
	}
	
	public Book(int bookId, String title, String author, GENRE genre) {
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.genre = genre;
	}
	
	@Override
	public String toString() {
		return "ID: " + bookId + ", Title: " + title + ", Written By: " + author + ", Genre: " + genre;
	}
	
}

