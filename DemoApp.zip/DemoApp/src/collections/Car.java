package collections;

public class Car {
	String model;
	String company;
	
	
	public Car(String model, String company) {
		this.model = model;
		this.company = company;
	}
	
	@Override
	public String toString() {
		return "Company: " + company + ", Model: " + model;
	}
}
