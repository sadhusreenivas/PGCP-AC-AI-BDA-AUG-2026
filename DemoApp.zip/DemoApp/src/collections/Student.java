package collections;

public class Student implements Comparable<Student> {
	int rollNo;
	String name;
	
	public Student(int rollNo, String name) {
		this.rollNo = rollNo;
		this.name = name;
	}
	
	@Override
	public int compareTo(Student s) {
		if(this.rollNo < s.rollNo) {
			return -1;
		} else if(this.rollNo > s.rollNo) {
			return 1;
		} else {
			return 0;
		}
	}
	
	@Override
	public String toString() {
		return "Roll Number: " + rollNo + ", Name: " + name;
	}
}













//ArrayList<Student> sl = new ArrayList<>();
//
//sl.add(new Student(1, "Rahul"));
//sl.add(new Student(2, "Vikalp"));
//sl.add(new Student(3, "Vaishnavi"));
//
//al.add(23);
//al.add("true");
//al.add(true);
//
//String stud = sl.get(0).toString();
//System.out.println(stud);