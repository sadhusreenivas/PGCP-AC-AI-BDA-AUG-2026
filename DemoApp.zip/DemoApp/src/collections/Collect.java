package collections;

import java.util.*;

import collections.Book.GENRE;
public class Collect {

	public static void main(String[] args) {
		
//		int[] arr = new int[5];
//		
//		ArrayList al = new ArrayList<>();
//		
//		al.add("Hello");
//		al.add(23);
//		al.add("Areen");
//		al.add("Bharat");
//		al.add("Vinod");
		
		
//		Iterator itr = al.iterator();
		
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		
//		Stack s = new Stack();
//		
//		s.push("Himanshu");
//		s.push("Durgesh");
//		s.push("Namira");
//		s.push("Shivam");
//		s.push("Naredra");
//		s.push("Advika");
//		s.pop();
//		s.pop();
//		s.push("Faiz");
//		Collections.sort(s);
		
//		Iterator itr = s.iterator();
		
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		
//		s.pop();
//		System.out.println(s.peek());
//		s.peek();
		
//		LinkedList ll = new LinkedList();
//		
//		ll.add("Isha");
//		ll.add("Honey");
//		ll.add("Saurabh");
		
//		System.out.println(ll.get(1));
		
		
//		System.out.println(al);
//		System.out.println(al.contains("Hello"));
		
		
//		HashSet hs = new HashSet();
//		
//		hs.add(42);
//		hs.add(83);
//		hs.add(11);
//		
//		Iterator itr = hs.iterator();
//		
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		
		
//		COMPARTORS
		
		TreeSet<Student> students = new TreeSet<>();
		
		students.add(new Student(27, "Shivam"));
		students.add(new Student(10, "Tejas"));
		students.add(new Student(50, "Namira"));
		
//		System.out.println(students);
		
		TreeSet<Book> books = new TreeSet<>(new TitleComparator());
		books.add(new Book(2, "Harry Potter: Goblet of Fire", "J.K Rowling", GENRE.FICTION));
		books.add(new Book(1, "The ALchemist", "Paulo Cohelo", GENRE.FICTION));
		books.add(new Book(3, "Game of Thrones", "R R Martin", GENRE.FICTION));
		books.add(new Book(4, "Wings of Fire", "APJ Abdul Kalam", GENRE.FICTION));
		books.add(new Book(5, "Fate Stay/Night", "Kinoko Nasu", GENRE.FICTION));
		
//		System.out.println(books);
		
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("CDAC", "Java course");
		map.put("Random Institute", "Python");
		
		System.out.println(map);
		
		
		



	}

}




















//ArrayList al = new ArrayList<>();