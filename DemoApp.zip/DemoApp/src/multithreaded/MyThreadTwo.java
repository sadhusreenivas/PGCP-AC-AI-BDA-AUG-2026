package multithreaded;

public class MyThreadTwo extends Thread{
    Table t;

	public MyThreadTwo(Table t) {
		this.t = t;
	}

	@Override
	public void run() {
		
	}

}
