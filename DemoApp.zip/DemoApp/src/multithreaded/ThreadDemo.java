package multithreaded;
public class ThreadDemo extends Thread {

	public void run() {
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getPriority());
		
		if(Thread.currentThread().getName().equals("first")) {
			System.out.println("Its has NORM_PRIORITY");
		}
		
	}
	
	public static void main(String[] args) {
		
		ThreadDemo t1 = new ThreadDemo();
		ThreadDemo t2 = new ThreadDemo();
		ThreadDemo t3 = new ThreadDemo();
		
		t1.setName("first");
		t3.setName("third");
		
		t2.setPriority(MAX_PRIORITY);
		t3.setPriority(2);
		
		t1.setDaemon(true);
		
		t1.start();
		t2.start();
		t3.start();
		
		System.out.println(t1.isDaemon());
	}

}
