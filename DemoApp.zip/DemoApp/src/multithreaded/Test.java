package multithreaded;
public class Test {
	public static void main(String[] args) {
		
		Table t = new Table();
		Thread t1 = new Thread() {
			public void run() {
				t.printTable(17);
			}
		};
		t1.start();
		
		Thread t2 = new Thread() {
			public void run() {
				t.printTable(18);
			}
		};
		t2.start();
		
		Thread t3 = new Thread() {
			public void run() {
				t.printTable(19);
			}
		};
		t3.start();
		
		
	}

}
