package multithreaded;
public class Display {
	
	public synchronized void dispUpperCase() {
		for(int i=65; i<=90; i++) {
			System.out.print((char)i+" ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public synchronized void dispLowerCase() {
		for(int i=97; i<=122; i++) {
			System.out.print((char)i+" ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public synchronized void dispNumbers() {
		for(int i=1; i<=26; i++) {
			System.out.print(i+" ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	}
}
