package multithreaded;
public class Multi extends Thread{
	@Override
	public void run() {
		for(int i=1; i<=10; i++) {
			System.out.println(i);
			try {
				Thread.sleep(750);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {
		
		Multi t1 = new Multi();
		Multi t2 = new Multi();
		Multi t3 = new Multi();
		
		t1.start();
		t1.join(3000); //
		
		t2.start();
		t3.start();
		
		
	}

}
