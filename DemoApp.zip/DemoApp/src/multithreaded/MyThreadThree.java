package multithreaded;

public class MyThreadThree extends Thread{
    Table t;
	public MyThreadThree(Table t) {
		this.t = t;
	}

	@Override
	public void run() {
		
	}

}
