package multithreaded;

public class MyThreadOne extends Thread {
	Table t;
	
	public MyThreadOne(Table t) {
		this.t = t;
	}

	@Override
	public void run() {
		
	}
	
	

}
