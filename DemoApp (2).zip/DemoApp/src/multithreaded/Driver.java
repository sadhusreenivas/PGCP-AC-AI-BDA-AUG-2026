package multithreaded;
public class Driver {

	public static void main(String[] args) {
		Display d = new Display();
		
//		new Thread() {
//			public void run() {
//				d.dispUpperCase();
//			}
//		}.start();
		
		Runnable r1 = ()-> d.dispUpperCase();
		new Thread(r1).start();
		
		new Thread() {
			public void run() {
				d.dispLowerCase();
			}
		}.start();
	
		new Thread() {
			public void run() {
				d.dispNumbers();
			}
		}.start();
	
	
	}

}
