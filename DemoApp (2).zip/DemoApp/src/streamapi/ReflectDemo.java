package streamapi;
import java.lang.reflect.*;
import java.util.*;
public class ReflectDemo {
	public static void main(String[] args) {
		
		//String s1 = "C-DAC Hyd";
		//Thread s1 = new Thread();
		Date s1 = new Date();
		Class c = s1.getClass(); //
		System.out.println(c.getName());
		int mc = 0;
		Method[] m = c.getDeclaredMethods();
		for(Method m1: m) {
			System.out.println(m1);
			mc++;
		}
		int fc = 0;
		System.out.println(mc);
        Field[] f = c.getDeclaredFields();
        for(Field f1: f) {
			System.out.println(f1);
			fc++;
		}
		System.out.println(fc);
	}

}
