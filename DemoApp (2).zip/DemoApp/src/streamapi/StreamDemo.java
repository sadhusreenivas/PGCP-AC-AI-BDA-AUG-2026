package streamapi;
import java.util.*;
import java.util.stream.Collectors;
public class StreamDemo {

	public static void main(String[] args) {
		
   List<String> names = Arrays.asList("India", "Brazil","China","Russia","South Africa","Indonesia","Iran", "Iraq");
   
   Set<String> iCountries = names.stream()
		                    .filter(s->s.startsWith("I"))
		                    .map(String::toUpperCase)
		                     .skip(1)
		                   // .limit(2)
		                    .collect(Collectors.toSet());
 
     System.out.println(iCountries);
     
     names.stream()
     .filter(s->s.startsWith("I"))
     .map(String::toUpperCase)
    // .skip(1)
    // .limit(2)
     .forEach(System.out::println);
     
     
	}

}
