package streamapi;
import java.util.*;

public class ListDemo {
	public static void main(String[] args) {
		
		List<String> cities = Arrays.asList("hyd","ngp","bpl","lko","idr","vskp");
		System.out.println(cities);
		
//		System.out.println("***********************");
//		for(String s: cities)
//			System.out.println(s);
//		System.out.println("***********************");
//		Iterator<String> itr = cities.iterator();
//		while(itr.hasNext())
//			System.err.println(itr.next());
//		System.out.println("***********************");
//		cities.stream().forEach(System.out::println);
//		System.out.println("***********************");
//		cities.stream().forEach(x->System.out.println(x));
		
		Collections.sort(cities); // ASC
		System.out.println(cities);
		
		Collections.sort(cities, new Comparator<String>() {
			public int compare(String s1, String s2) {
				return s2.compareTo(s1);
			}
		});
		System.out.println(cities);
		
		//lambda
		Collections.sort(cities, (s1, s2) -> s2.compareTo(s1));
		System.out.println(cities);
	}

}
