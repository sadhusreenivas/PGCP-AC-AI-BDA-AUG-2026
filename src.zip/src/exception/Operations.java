package exception;
import java.util.*;
public class Operations {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter 2 nums");
		try {
			int num1 = scanner.nextInt();
			int num2 = scanner.nextInt();
			System.out.println("sum  : "+(num1+num2));
			System.out.println("sub  : "+(num1-num2));
			System.out.println("mul  : "+(num1*num2));
			System.out.println("div  : "+(num1/num2));
		}
		catch(InputMismatchException i) {
			System.out.println(i);
		}
		catch(ArithmeticException j) {
//			System.err.println(e.getMessage());
			j.printStackTrace();
		}
		catch(Exception e ) {
			System.out.println(e);
		}
		finally{
			System.out.println("rest of code.......");
		}
	}

}
