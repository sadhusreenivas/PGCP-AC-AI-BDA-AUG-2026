package exception;

public class StringsDemo {
	 public static void main(String[] args) {
		 
		String s1 = "hello";
		StringBuilder sb = new StringBuilder(s1);
		sb = sb.append("welcome");
		System.out.println(sb.toString());
		
	
		
				
	}
}
