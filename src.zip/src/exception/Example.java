package exception;
import java.util.*;
class InvalidAgeException extends Exception{
	InvalidAgeException(String msge){
		super(msge);
	}
}
public class Example {
	public static void checkAge(int age) throws InvalidAgeException {
		if(age < 18 ) {
//			System.out.println("eligible");
			throw new InvalidAgeException(" not eligible.....");
		}
		System.out.println("eligible");
	}
	public static void main(String[] args) {
		try {
		checkAge(10);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			System.out.println("rest of code........");
		}
	}
}
