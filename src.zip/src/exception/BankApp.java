package exception;
public class BankApp {
	private double bal;
	public BankApp(double bal) {
		this.bal = bal;
	}
	public void withdraw(int amount) throws InsufficientFundsException{
		if(amount > bal)
			throw new InsufficientFundsException("less balance");
		
		bal = bal - amount;
		System.out.println("Balance: "+bal);
	}
	
	public static void main(String[] args) {
		BankApp app = new BankApp(40000);
		try {
		app.withdraw(25000);
		app.withdraw(25000); //
		}
		catch(Exception e) {System.out.println(e);}
		finally {
			System.out.println("Finally always gets excuted!");
		}
		
	}

}
