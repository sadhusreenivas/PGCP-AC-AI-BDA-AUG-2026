package inheritance;

public class ClassicCustomer extends Customer{
	
	private double intRate;
	private double wLimit;
	public ClassicCustomer(int cid, String cname, double balance, double intRate, double wLimit) {
		super(cid, cname, balance);
		this.intRate = intRate;
		this.wLimit = wLimit;
	}
	
	@Override
	public void calInterest() {
		double si = balance * 2.5 * 0.06;
			System.out.println("Interest earned: "+si);
			balance += si;
			System.out.println("Total Bal: "+balance);
		}

	@Override
	public void getCustomer() {
		super.getCustomer();
		System.out.println(intRate+" "+wLimit);
	}
	}
