package inheritance;

public class BankApp {
	public static void main(String[] args) {
	
		Customer cc1 = new ClassicCustomer(1234, "ABC", 100000, 0.06, 50000);
		cc1.getCustomer(); // RTP
		cc1.calInterest();// RTP

	}

}
