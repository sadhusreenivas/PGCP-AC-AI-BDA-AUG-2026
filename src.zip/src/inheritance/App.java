package inheritance;

public class App {

	public static void main(String[] args) {
		
		Animal a = new Animal();
		a.speak();
		Dog d = new Dog();
		d.speak();
		
		//RTP
		a = d; // upcasting
		a.speak(); // overridden
	}

}
