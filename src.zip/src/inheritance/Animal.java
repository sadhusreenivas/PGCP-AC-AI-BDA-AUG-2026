package inheritance;
public class Animal {
	
	public void speak() {
		System.out.println("Make sounds");
	}
}
class Dog extends Animal{

	@Override
	public void speak() {
		//super.speak();
		System.out.println("Bow..Bow!");
	}
}