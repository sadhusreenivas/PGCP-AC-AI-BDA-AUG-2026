package inheritance;
public class Customer {
	private int cid;
	private String cname;
	protected double balance;
	private static String bank ="SBI";
	
	public Customer(int cid, String cname, double balance) {
		this.cid = cid;
		this.cname = cname;
		this.balance = balance;
	}

	public void getCustomer() {
		System.out.println(cid+" "+cname+" "+balance+" "+bank);
	}
	
	// business method - rate = 4%, time = 2.5
	public void calInterest() {
	double si = balance * 2.5 * 0.04;
		System.out.println("Interest earned: "+si);
		balance += si;
		System.out.println("Total Bal: "+balance);
	}
	
}
