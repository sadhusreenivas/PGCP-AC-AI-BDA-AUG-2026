package packages;

public class Date {
	
	public void getDate() {
		System.out.println("Time: 1:10pm");
	}

}
