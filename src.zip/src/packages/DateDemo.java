package packages;
import java.util.*; // explicit
import java.sql.*; // implicit

public class DateDemo {

	public static void main(String[] args) {
		
		System.out.println(new Date());
		
		Date d = new Date();
		d.getDate();

	}

}
