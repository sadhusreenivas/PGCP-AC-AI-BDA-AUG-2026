package iostreams;
import java.io.*;

public class RW {
	public static void main(String[] args) throws IOException{
		
		FileReader fr = new FileReader("C:/Users/cdac/Desktop/Java_Programs/DemoApp/src/iostreams/RW.java");
		BufferedReader br = new BufferedReader(fr);
		
		//FileWriter fw = new FileWriter("C:/Users/cdac/Desktop/files/RWDemo.java",true);
		BufferedWriter bw = new BufferedWriter(new FileWriter("C:/Users/cdac/Desktop/files/RWDemo.java",true));
		
//		int c;
//		while( (c=br.read()) !=-1) {
//			bw.write(c);
//			// BL
//			System.out.print((char)c);
//		}
		
		String line = br.readLine();
		while(line != null) {
			bw.write(line);
			System.out.println(line);
			line = br.readLine();
		}

	br.close();
	bw.close();
}
}