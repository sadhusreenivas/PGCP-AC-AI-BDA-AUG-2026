package iostreams;
import java.io.*;

public class FWDemo {
	public static void main(String[] args) throws IOException {
		
		File file = new File("C:/Users/cdac/Desktop/files/abc.txt");
		FileWriter fw = new FileWriter(file, true); //append = false
		
		fw.write("\nJava is my fav language\nJava is OOP\nJava is robust");
		fw.write("\nJava is PI\nJava is secure");
		fw.write("\nJava is simple\nJava is multithreaded");
		
		fw.close();
		System.out.println("file written successfully!");
		
	}
}


