package iostreams;
import java.io.*;
public class FRDemo {
	public static void main(String[] args) throws IOException {
		
		FileReader fr = new FileReader("C:/Users/cdac/Desktop/files/abc.txt");
		
		int c;
		int lines = 0;
		int words = 0;
		int chars = 0;
		while( (c = fr.read()) != -1) {
			System.out.print((char)c);
			if(c =='\n')
				lines++;
			
			if(c == ' ')
				words++;
			
			chars++;
		}
		
		fr.close();
		System.out.println("No of lines: "+(lines+1));
		System.out.println("No of words: "+(lines+words));
		System.out.println("No of chars: "+chars);

	}

}
