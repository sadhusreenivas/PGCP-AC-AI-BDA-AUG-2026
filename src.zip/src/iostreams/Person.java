package iostreams;

import java.io.Serializable;

public class Person implements Serializable{

	private int age;
	private String name;
	transient private String pwd;
	
	public Person(int age, String name, String pwd) {
		this.age = age;
		this.name = name;
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", pwd=" + pwd + "]";
	}
	
}
