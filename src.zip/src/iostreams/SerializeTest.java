package iostreams;
import java.io.*;
public class SerializeTest {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Person p1 = new Person(25,"ABC","1234567");
		System.out.println(p1);
		// Serialization
		FileOutputStream fos = new FileOutputStream("C:/Users/cdac/Desktop/files/person.cdac");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(p1);
		
		// De-serailization
		FileInputStream fis = new FileInputStream("C:/Users/cdac/Desktop/files/person.cdac");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Person p2 = (Person) ois.readObject();
		
		System.out.println(p2);
	
	}

}
