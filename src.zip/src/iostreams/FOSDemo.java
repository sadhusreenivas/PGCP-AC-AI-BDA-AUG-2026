package iostreams;
import java.io.*;
public class FOSDemo {

	public static void main(String[] args) throws IOException {
		
		FileOutputStream fos = new FileOutputStream("C:/Users/cdac/Desktop/files/asdf.acaibda");
		String str = "Java is #1 development platform";
		
		byte[] bytes = str.getBytes();
		fos.write(bytes);
		
		fos.close();
		System.out.println("success");
		
	}

}
