package cdac.hyd.in;

import bda.*; // implicit
import ai.AI; // explicit

public class CDAC {

	public static void main(String[] args) {
		
		BDA bda = new BDA();
		AI ai = new AI();
		
		int classTotal = bda.getTotal() + ai.getTotal()+new ac.AC().getTotal();
		System.out.println(classTotal);

	}

}
