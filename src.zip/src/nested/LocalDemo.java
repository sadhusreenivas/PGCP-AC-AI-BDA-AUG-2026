package nested;

public class LocalDemo {
private String name = "C-DAC Hyd";

void disp() {
	class Local{
		void msg() {
			System.out.println(name);
		}
	} // class end
	
	Local l = new Local();
	l.msg();
} // method end
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDemo ld = new LocalDemo();
		ld.disp();
        
	}

}
