package nested;

public class AICDemo {
	public static void main(String[] args) {
		
		Person p1 = new Person() {
			@Override
			public void speak() {
				System.out.println("English");
			}
           @Override
			public void eat() {
				System.out.println("Fruits!");
			}
		};
		p1.eat();
		p1.speak();
	}

}
