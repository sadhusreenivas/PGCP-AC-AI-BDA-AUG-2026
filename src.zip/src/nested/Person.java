package nested;

public interface Person {
	void speak();
	void eat();
	
	public static void main(String[] args) {
		
		Person p1 = new Person() {
			public void speak() {
				System.out.println("Java!");
			}
			public void eat() {
			System.out.println("Dal Bati");
			}
		};
		
		p1.eat();
		p1.speak();
	}
}
