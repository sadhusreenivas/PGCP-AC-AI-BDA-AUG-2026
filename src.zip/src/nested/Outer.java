package nested;
public class Outer {
	private String name = "Java26...";
	
	class Inner{
		void msg() {
			System.out.println(name);
		}
	}
	void disp() {
		Inner in = new Inner();
		in.msg();
	}
	
	public static void main(String[] args) {
	
        Outer out = new Outer();
//		Outer.Inner in = out.new Inner();
//		in.msg();
        out.disp();
		
		
	}

}
