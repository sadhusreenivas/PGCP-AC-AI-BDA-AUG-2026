package bda;

public class BDA {
	int total = 43;
	public int getTotal() {
		return total;
	}

}
