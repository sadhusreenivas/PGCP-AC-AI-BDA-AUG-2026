package ai;

public class AI {
	int total = 30;
	public int getTotal() {
		return total;
	}
}
