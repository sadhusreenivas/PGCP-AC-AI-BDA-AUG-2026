package abstraction;
public class Bank extends RBI {
   private String name;
   
	public Bank(String name, int cashback, String bname) {
	super(name, cashback); //
	this.name = bname;
}

	@Override
	void deposit(int amount) {
		System.out.println(amount+" is deposited");
		System.out.println("You got cashback" +getCashback());
	}

	@Override
	void withdraw(int amount) {
		System.out.println(amount +" withdrawn");
		System.out.println("You got cashback" +getCashback());
	}

	@Override
	public void disp() {
		System.out.println("I'm Bank: "+name);
	}
	
	public void calProfits() {
		System.out.println("Profit is.....");
	}

}
