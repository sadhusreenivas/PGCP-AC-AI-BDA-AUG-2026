package abstraction;

public interface XYZ {

	void xyz();
	
	
}
