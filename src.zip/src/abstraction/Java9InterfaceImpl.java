package abstraction;

public class Java9InterfaceImpl implements Java9Interface{
	public static void main(String[] args) {
    
		Java9InterfaceImpl java9 = new Java9InterfaceImpl();
		java9.test();
		java9.print();
		Java9Interface.fun();
		
		

	}

	@Override
	public void test() {
		System.out.println(name);
		
	}

}
