package abstraction;

abstract public class RBI {

private String name;
private int cashback;

public RBI(String name, int cashback) {
	this.name = name;
	this.cashback = cashback;
}

public void disp() {
	System.out.println("Name: "+name);
}

abstract void deposit(int amount);
abstract void withdraw(int amount);

public String getName() {
	return name;
}

public int getCashback() {
	return cashback;
}
	

}
