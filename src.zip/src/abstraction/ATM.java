package abstraction;

public interface ATM extends XYZ{
	
    int CASHABACK = 25;
	void withdraw();
	void deposit();
	void transfer();
}
