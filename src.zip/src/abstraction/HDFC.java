package abstraction;
public class HDFC implements ATM, TTP{
	public static void main(String[] args) {
		ATM atm = new HDFC();
		atm.deposit();
		atm.transfer();
		atm.withdraw();
		atm.xyz();
		
		TTP visa = new HDFC();
		visa.confirmTransaction();
	}

	@Override
	public void withdraw() {
		System.out.println("withdraw success and you got cashback: "+CASHABACK);
	}
	@Override
	public void deposit() {
		System.out.println("deposit success and you got cashback: "+CASHABACK);
	}

	@Override
	public void transfer() {
		System.out.println("transfer success and you got cashback: "+CASHABACK);
	}
	@Override
	public void confirmTransaction() {
		System.out.println(" Transaction confirmed");
		
	}

	@Override
	public void xyz() {
		System.out.println(" Inheritance demo");
		
	}

}
