package abstraction;
public interface Java9Interface {
	String name ="C-DAC Hyd";
	void test();
	
	// default
	default void print() {
		System.out.println("Its a default method from interface");
		disp();
	}
	static void fun() {
		System.out.println("static method from Interface");
		show();
	}
	private void disp() {
		System.out.println("private methos from Interface");
	}
	private static void show() {
		System.out.println("Ist private static method from Interface");
	}
	
}
