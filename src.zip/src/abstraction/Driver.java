package abstraction;

public class Driver {

	public static void main(String[] args) {
		
		RBI r = new Bank("rbi.org", 10,"SBI");
		r.deposit(10000);
		r.withdraw(5000);
		r.disp();
		
		new Bank("rbi.org", 10,"SBI").calProfits(); // Anonymous Object
	}  

}
