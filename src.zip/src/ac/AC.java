package ac;

public class AC {
   int total = 97;
	public int getTotal() {
		return total;
	}
}
